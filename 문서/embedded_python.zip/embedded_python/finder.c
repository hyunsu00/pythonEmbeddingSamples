#include <Python.h>

int main(int argc, char** argv)
{
  Py_SetProgramName(argv[0]);
  Py_Initialize();
  
  if (Py_IsInitialized()) {
    /* module, class, instance */
    PyObject *mod = NULL, *cls = NULL, *ins = NULL;

    /* argument, return */
    PyObject *url = NULL, *ret = NULL;

    PySys_SetArgv(argc, argv);

    mod = PyImport_ImportModule("scripts.finder");   // module
    cls = PyObject_GetAttrString(mod, "url_finder"); // class
  
    /* argument must be a tuple */
    url = PyTuple_New(1);    
    PyTuple_SetItem(url, 0, PyString_FromString(argv[1])); // (url)

    ins = PyObject_CallObject(cls, url);        // instance
    ret = PyObject_GetAttrString(ins, "links"); // instance.links
    
    if (PyList_Check(ret)) {
      PyObject* iter = PyObject_GetIter(ret);
      PyObject* item;

      while(item = PyIter_Next(iter)) {
        if (PyString_Check(item)) {
          printf("%s\n", PyString_AsString(item));
        }
        Py_XDECREF(item);
      }
      Py_XDECREF(iter);
    }
    Py_XDECREF(ret);
    Py_XDECREF(ins);
    Py_XDECREF(url);
    Py_XDECREF(cls);
    Py_XDECREF(mod);
    Py_Finalize();
  }

  return 0;
}