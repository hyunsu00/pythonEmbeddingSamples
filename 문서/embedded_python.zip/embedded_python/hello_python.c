#include <Python.h>

int main(int argc, char** argv)
{
  Py_Initialize();

  if (Py_IsInitialized()) {
    PyRun_SimpleString("print \'Hello, World!\'\n");
    Py_Finalize();
  }

  return 0;
}