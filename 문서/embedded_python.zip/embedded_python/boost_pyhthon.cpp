#include <boost/python.hpp>
#include <Python.h>
#include <iostream>

int main(int argc, char** argv) 
{
  Py_Initialize();
  //PyObject* naive = PyString_FromString("naive_string");
  boost::python::object
    bpobj(
      boost::python::handle<>(
        PyString_FromString("boost::python handling object")));

  boost::python::object
    bpobj_another = bpobj;

  //if (naive)
  //  Py_XDECREF(naive);
  Py_Finalize();
  return 0;
}