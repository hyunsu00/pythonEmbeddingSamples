#include <boost/python.hpp>
#include <iostream>

namespace bp = boost::python;
typedef bp::object bpobj;

inline bpobj createObject(PyObject* op)
{
  if (op == NULL) {
    throw bp::error_already_set();
  }

  return bpobj(bp::handle<>(op));
}

void boostFinder(const char* url)
{
  // import module
  bpobj module = createObject(PyImport_ImportModule("scripts.finder"));

  // get class object, instantiate the class
  bpobj klass = module.attr("url_finder")(url);

  // url_finder.links
  bp::list links = bp::extract<bp::list>(klass.attr("links"));
  
  if (PyList_Check(links.ptr()))
  {
    typedef Py_ssize_t psz_t;

    const psz_t linkSize = Py_SIZE(links.ptr());
    for (psz_t i = 0; i < linkSize; ++i)
    {
      // borrowed reference
      std::cout << PyString_AsString(PyList_GET_ITEM(links.ptr(), i))
                << '\n';
    }
  }
}

int main(int argc, char **argv)
{
  if (argc < 2) {
    std::cerr << "specify a url.\n";
    return 1;
  }

  if (Py_Initialize(), Py_IsInitialized())
  {
    try
    {
      PySys_SetArgv(argc, argv);
      boostFinder(argv[1]);
    }
    catch (bp::error_already_set const &)
    {
      PyErr_Print();
    }
    Py_Finalize();
  }
  return 0;
}