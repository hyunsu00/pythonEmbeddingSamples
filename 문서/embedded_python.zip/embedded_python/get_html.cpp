#include <boost/python.hpp>
#include <iostream>
#include <fstream>

namespace bp = boost::python;
typedef bp::object bpobj;

inline bpobj CreateObject(PyObject* op)
{
  if (op == NULL) throw bp::error_already_set();
  return bpobj(bp::handle<>(op));
}

void PrintUsage(std::ostream& os)
{
  os << "< Save URL >\n";
  os << "get_html <url> <file_name>\n";
  os << "options:\n";
}

int main(int argc, char** argv)
{
  if (argc < 3) {
    PrintUsage(std::cerr);
    return 1;
  }

  if (Py_Initialize(), Py_IsInitialized()) {
    try {
      const char *url = argv[argc - 2];
      const char *file_name = argv[argc - 1];

      bpobj urllib  = CreateObject(PyImport_ImportModule("urllib"));
      bpobj connobj = urllib.attr("urlopen")(url);
      bpobj htmlobj = connobj.attr("read")();
      connobj.attr("close")();

      // save as file
      const char *html = bp::extract<const char*>(htmlobj);
      const int byte = bp::extract<const int>(htmlobj.attr("__len__")());
        
      std::ofstream os(file_name, std::ios::binary);
      
      if (os.is_open()) {
        os.write(html, byte);
        printf("%d bytes written to %s\n", byte, file_name);
        os.close();
      }
    }
    catch (bp::error_already_set const &) {
      PyErr_Print();
    }
    Py_Finalize();
  }
  return 0;
}