def PrintMyDef():
    print "Hello, MyDef!"
    
def Multiply(x, y):
    return x * y
    
class MyClass:
    def __init__(self):
        print "MyClass instantiated"

    def __del__(self):
        print "MyClass deleted"

    def Test(self):
        print "Ok, tested!"